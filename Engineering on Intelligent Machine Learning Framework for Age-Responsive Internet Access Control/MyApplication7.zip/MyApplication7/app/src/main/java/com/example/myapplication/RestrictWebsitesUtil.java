package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

public class RestrictWebsitesUtil {
    public static void openWebsiteIfAllowed(Activity activity, int userAge, String websiteName) {
        String url = null;
        String siteDisplayName = websiteName;
        switch (websiteName.toLowerCase()) {
            case "facebook":
                url = "https://www.facebook.com";
                siteDisplayName = "Facebook";
                break;
            case "tiktok":
                url = "https://www.tiktok.com";
                siteDisplayName = "TikTok";
                break;
            default:
                url = websiteName; // fallback: treat as URL
        }
        if ((siteDisplayName.equalsIgnoreCase("Facebook") || siteDisplayName.equalsIgnoreCase("TikTok")) && userAge < 26) {
            Toast.makeText(activity, "Access denied: You must be 25 or older to use " + siteDisplayName + ".", Toast.LENGTH_LONG).show();
        } else {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            activity.startActivity(browserIntent);
        }
    }
}