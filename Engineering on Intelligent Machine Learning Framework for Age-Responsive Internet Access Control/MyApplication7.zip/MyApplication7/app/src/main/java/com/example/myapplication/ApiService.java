package com.example.myapplication;

import android.util.Log;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;

public class ApiService {
    private static final String TAG = "ApiService";
    private static final String SERVER_URL = " http://192.168.0.106:5000/predict"; // Change to your Flask URL

    public interface ApiCallback {
        void onSuccess(int responseCode, String responseBody);
        void onError(String errorMessage);
    }

    public static void sendImageToServer(byte[] imageData, ApiCallback callback) {
        new Thread(() -> {
            try {
                URL url = new URL(SERVER_URL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/octet-stream");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                os.write(imageData);
                os.flush();
                os.close();

                int responseCode = conn.getResponseCode();
                Log.d(TAG, "Response Code: " + responseCode);

                InputStream is = null;
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    is = conn.getInputStream();
                } else {
                    is = conn.getErrorStream();
                }
                String responseBody = readStream.readStream(is);

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    if (callback != null) {
                        callback.onSuccess(responseCode, responseBody);
                    }
                } else {
                    throw new Exception("Server returned response code: " + responseCode + ", body: " + responseBody);
                }

            } catch (Exception e) {
                Log.e(TAG, "Error sending image: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Failed to send image: " + e.getMessage());
                }
            }
        }).start();
    }
}