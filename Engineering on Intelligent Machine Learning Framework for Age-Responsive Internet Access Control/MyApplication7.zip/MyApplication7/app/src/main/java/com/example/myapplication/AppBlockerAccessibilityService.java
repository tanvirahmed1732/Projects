package com.example.myapplication;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

public class AppBlockerAccessibilityService extends AccessibilityService {

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Get the package name of the foreground app
        String packageName = String.valueOf(event.getPackageName());

        // Get user age from SharedPreferences
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        int userAge = prefs.getInt("user_age", -1);

        // Block Facebook and TikTok if user is under 26
        if (userAge < 26 && (packageName.equals("com.facebook.katana") || packageName.equals("com.zhiliaoapp.musically"))) {
            // Show a toast and go to home screen
            Toast.makeText(this, "Access to this app is blocked!", Toast.LENGTH_SHORT).show();
            performGlobalAction(GLOBAL_ACTION_HOME);
        }
    }

    @Override
    public void onInterrupt() {
        // Required override, can be left empty
    }
}